// static/js/app.js
// Shared behaviour used across every page: toasts, nav state, notifications.

// ---------- Toast ----------
function showToast(message, type = 'info') {
    let container = document.getElementById('toastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toastContainer';
        document.body.appendChild(container);
    }

    const icons = { success: 'fa-circle-check', error: 'fa-circle-exclamation', info: 'fa-circle-info' };
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `<i class="fas ${icons[type] || icons.info}"></i><span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.3s';
        setTimeout(() => toast.remove(), 300);
    }, 3200);
}

// ---------- Mobile nav toggle ----------
document.addEventListener('DOMContentLoaded', () => {
    const toggle = document.querySelector('.nav-toggle');
    const nav = document.querySelector('.site-nav');
    if (toggle && nav) {
        toggle.addEventListener('click', () => nav.classList.toggle('nav-open'));
    }
});

// ---------- Current user (used to light up nav state) ----------
async function loadNavUser() {
    const avatarSlot = document.getElementById('navAvatar');
    if (!avatarSlot) return;

    try {
        const res = await fetch('/api/auth/me');
        if (!res.ok) {
            avatarSlot.innerHTML = `<a href="/login" class="btn-secondary">Sign in</a>
                <a href="/register" class="btn-primary">Join</a>`;
            return;
        }
        const user = await res.json();
        const initials = user.name ? user.name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2) : 'U';
        avatarSlot.innerHTML = `
            <a href="/dashboard" class="nav-avatar" title="${user.name || 'Dashboard'}">${initials}</a>
            ${user.role === 'admin' ? '<a href="/admin" class="btn-secondary">Admin</a>' : ''}
        `;
    } catch (err) {
        console.error('Error loading nav user:', err);
    }
}

document.addEventListener('DOMContentLoaded', loadNavUser);

// ---------- Logout ----------
async function logoutUser() {
    try {
        await fetch('/api/auth/logout', { method: 'POST' });
        window.location.href = '/';
    } catch (err) {
        showToast('Failed to log out.', 'error');
    }
}
