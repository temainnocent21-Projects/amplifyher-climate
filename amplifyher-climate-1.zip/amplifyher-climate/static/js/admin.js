// static/js/admin.js
// Powers /admin: platform stats, story moderation, and policy brief generation.

async function initAdmin() {
    loadAdminStats();
    loadStoriesForModeration();

    document.querySelectorAll('.admin-nav button').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.admin-nav button').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            document.querySelectorAll('.admin-view').forEach(v => v.style.display = 'none');
            document.getElementById(btn.dataset.view).style.display = 'block';
            if (btn.dataset.view === 'viewBriefs') loadPolicyBriefs();
        });
    });
}

async function loadAdminStats() {
    try {
        const res = await fetch('/api/stats');
        const stats = await res.json();
        document.getElementById('statStories').textContent = stats.stories;
        document.getElementById('statDistricts').textContent = stats.districts;
        document.getElementById('statUsers').textContent = stats.users;
        document.getElementById('statBriefs').textContent = stats.briefs;
    } catch (err) {
        console.error('Error loading stats:', err);
    }
}

async function loadStoriesForModeration() {
    const tbody = document.getElementById('moderationTableBody');
    if (!tbody) return;

    try {
        const res = await fetch('/api/stories?status=all&limit=100');
        const data = await res.json();
        const stories = data.stories || [];

        if (stories.length === 0) {
            tbody.innerHTML = `<tr><td colspan="5">No stories submitted yet.</td></tr>`;
            return;
        }

        tbody.innerHTML = stories.map(s => `
            <tr>
                <td>${s.title}</td>
                <td>${s.user_name || s.author || 'Anonymous'}</td>
                <td>${s.district}</td>
                <td><span class="status-pill ${s.status}">${s.status}</span></td>
                <td>
                    <div class="row-actions">
                        ${s.status !== 'published' ? `<button onclick="setStoryStatus('${s.id}', 'published')">Publish</button>` : ''}
                        ${s.status !== 'rejected' ? `<button onclick="setStoryStatus('${s.id}', 'rejected')">Reject</button>` : ''}
                        <button class="danger" onclick="removeStory('${s.id}')">Delete</button>
                    </div>
                </td>
            </tr>
        `).join('');
    } catch (err) {
        console.error('Error loading stories:', err);
    }
}

async function setStoryStatus(storyId, status) {
    try {
        const res = await fetch(`/api/stories/${storyId}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ status })
        });
        if (res.ok) {
            showToast(`Story ${status}.`, 'success');
            loadStoriesForModeration();
            loadAdminStats();
        }
    } catch (err) {
        showToast('Failed to update story.', 'error');
    }
}

async function removeStory(storyId) {
    if (!confirm('Delete this story permanently?')) return;
    try {
        const res = await fetch(`/api/stories/${storyId}`, { method: 'DELETE' });
        if (res.ok) {
            showToast('Story deleted.', 'success');
            loadStoriesForModeration();
            loadAdminStats();
        }
    } catch (err) {
        showToast('Failed to delete story.', 'error');
    }
}

async function loadPolicyBriefs() {
    const list = document.getElementById('briefsList');
    if (!list) return;

    try {
        const res = await fetch('/api/policy/briefs');
        const data = await res.json();
        const briefs = data.briefs || [];

        if (briefs.length === 0) {
            list.innerHTML = `<div class="empty-state"><p>No policy briefs generated yet.</p></div>`;
            return;
        }

        list.innerHTML = briefs.map(b => `
            <div class="story-card">
                <span class="tag">${b.status}</span>
                <h3>${b.title}</h3>
                <p>${b.summary}</p>
                <div class="card-meta">
                    <span>${new Date(b.generated_at).toLocaleDateString()}</span>
                    <span>${b.downloads || 0} downloads</span>
                </div>
            </div>
        `).join('');
    } catch (err) {
        console.error('Error loading briefs:', err);
    }
}

async function generateBrief() {
    try {
        const res = await fetch('/api/policy', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ story_ids: [] })
        });
        const data = await res.json();
        if (res.ok) {
            showToast('Policy brief generated.', 'success');
            loadPolicyBriefs();
            loadAdminStats();
        } else {
            showToast(data.error || 'Could not generate brief.', 'error');
        }
    } catch (err) {
        showToast('Something went wrong.', 'error');
    }
}

document.addEventListener('DOMContentLoaded', initAdmin);
