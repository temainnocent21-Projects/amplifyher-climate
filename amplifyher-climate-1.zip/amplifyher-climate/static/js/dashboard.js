// static/js/dashboard.js
// Powers /dashboard: a user's own stories, a submission form, and notifications.

let dashboardUser = null;

async function initDashboard() {
    try {
        const res = await fetch('/api/auth/me');
        if (!res.ok) {
            window.location.href = '/login';
            return;
        }
        dashboardUser = await res.json();
        document.getElementById('dashboardGreeting').textContent = `Welcome back, ${dashboardUser.name.split(' ')[0]}`;
        loadMyStories();
        loadNotifications();
    } catch (err) {
        console.error('Error initializing dashboard:', err);
    }
}

async function loadMyStories() {
    const grid = document.getElementById('myStoriesGrid');
    if (!grid) return;

    try {
        const res = await fetch(`/api/stories?search=&status=all&limit=100`);
        const data = await res.json();
        const mine = (data.stories || []).filter(s => s.user_id === dashboardUser.id);

        if (mine.length === 0) {
            grid.innerHTML = `<div class="empty-state">
                <i class="fas fa-feather"></i>
                <p>You haven't shared a story yet. Your experience could shape a policy brief.</p>
            </div>`;
            return;
        }

        grid.innerHTML = mine.map(s => `
            <div class="story-card">
                <span class="tag">${s.category} · ${s.status}</span>
                <h3><a href="/story/${s.id}" style="color:inherit;">${s.title}</a></h3>
                <p>${s.content}</p>
                <div class="card-meta">
                    <span><i class="fas fa-map-pin"></i> ${s.district}</span>
                    <span><i class="fas fa-heart"></i> ${s.likes || 0}</span>
                </div>
            </div>
        `).join('');
    } catch (err) {
        console.error('Error loading stories:', err);
    }
}

async function loadNotifications() {
    const list = document.getElementById('notificationList');
    if (!list) return;

    try {
        const res = await fetch('/api/notifications');
        const data = await res.json();
        const notifications = data.notifications || [];

        if (notifications.length === 0) {
            list.innerHTML = `<div class="empty-state" style="padding:1.5rem;">
                <p>No notifications yet.</p>
            </div>`;
            return;
        }

        list.innerHTML = notifications.map(n => `
            <div class="story-card" style="padding:1rem;">
                <p style="margin:0;">${n.message}</p>
                <div class="card-meta" style="border:none; padding-top:0.3rem;">
                    <span>${new Date(n.created_at).toLocaleDateString()}</span>
                    ${n.link ? `<a href="${n.link}">View</a>` : ''}
                </div>
            </div>
        `).join('');
    } catch (err) {
        console.error('Error loading notifications:', err);
    }
}

async function submitStory(event) {
    event.preventDefault();
    const errorEl = document.getElementById('storyFormError');
    errorEl.classList.remove('show');

    const payload = {
        title: document.getElementById('storyTitle').value,
        content: document.getElementById('storyContent').value,
        district: document.getElementById('storyDistrict').value,
        category: document.getElementById('storyCategory').value,
        language: document.getElementById('storyLanguage').value
    };

    try {
        const res = await fetch('/api/stories', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        const data = await res.json();

        if (res.ok) {
            showToast('Story submitted for review!', 'success');
            document.getElementById('storyForm').reset();
            loadMyStories();
        } else {
            errorEl.textContent = data.error || 'Could not submit story.';
            errorEl.classList.add('show');
        }
    } catch (err) {
        errorEl.textContent = 'Something went wrong. Please try again.';
        errorEl.classList.add('show');
    }
}

document.addEventListener('DOMContentLoaded', initDashboard);
