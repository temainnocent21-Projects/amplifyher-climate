# Paste the complete amplifyher_app.py code from your supplied specification here.
# This file is the main Flask application.
