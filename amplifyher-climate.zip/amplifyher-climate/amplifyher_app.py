# amplifyher_app.py
import os
import json
import uuid
from datetime import datetime, timedelta
from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from functools import wraps

app = Flask(__name__, static_folder='static', template_folder='templates')
app.secret_key = os.environ.get('SECRET_KEY', 'dev-secret-key-2026')
CORS(app)

# ========== DATABASE SETUP ==========
def get_db():
    conn = sqlite3.connect('amplifyher.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    cursor = conn.cursor()

    # Stories table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS stories (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            district TEXT NOT NULL,
            category TEXT NOT NULL,
            language TEXT DEFAULT 'English',
            author TEXT,
            user_id TEXT,
            date TEXT NOT NULL,
            likes INTEGER DEFAULT 0,
            status TEXT DEFAULT 'pending',
            lat REAL,
            lng REAL,
            media_images INTEGER DEFAULT 0,
            media_audio INTEGER DEFAULT 0,
            media_video INTEGER DEFAULT 0,
            views INTEGER DEFAULT 0
        )
    ''')

    # Users table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'user',
            created_at TEXT NOT NULL,
            last_login TEXT,
            profile_pic TEXT,
            bio TEXT,
            district TEXT,
            phone TEXT,
            twitter TEXT,
            instagram TEXT
        )
    ''')

    # Policy briefs table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS policy_briefs (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            summary TEXT NOT NULL,
            recommendations TEXT,
            story_ids TEXT,
            generated_at TEXT NOT NULL,
            status TEXT DEFAULT 'draft',
            downloads INTEGER DEFAULT 0
        )
    ''')

    # Comments table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS comments (
            id TEXT PRIMARY KEY,
            story_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            user_name TEXT NOT NULL,
            content TEXT NOT NULL,
            date TEXT NOT NULL,
            FOREIGN KEY (story_id) REFERENCES stories(id),
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')

    # Notifications table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS notifications (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            message TEXT NOT NULL,
            type TEXT DEFAULT 'info',
            read INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            link TEXT,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )
    ''')

    conn.commit()
    conn.close()

# ========== AUTH DECORATORS ==========
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Please login first'}), 401
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Please login first'}), 401
        if session.get('role') != 'admin':
            return jsonify({'error': 'Admin access required'}), 403
        return f(*args, **kwargs)
    return decorated_function

# ========== ROUTES ==========
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login')
def login_page():
    return render_template('login.html')

@app.route('/register')
def register_page():
    return render_template('register.html')

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

@app.route('/admin')
@admin_required
def admin_panel():
    return render_template('admin.html')

@app.route('/profile')
@login_required
def profile_page():
    return render_template('profile.html')

@app.route('/story/<story_id>')
def story_detail(story_id):
    return render_template('story_detail.html', story_id=story_id)

# ========== AUTH API ==========
@app.route('/api/auth/register', methods=['POST'])
def register():
    data = request.json
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute('SELECT * FROM users WHERE email = ?', (data['email'],))
    if cursor.fetchone():
        conn.close()
        return jsonify({'error': 'Email already registered'}), 400

    user_id = str(uuid.uuid4())[:8]
    now = datetime.now().isoformat()
    hashed_password = generate_password_hash(data['password'])

    cursor.execute('''
        INSERT INTO users (id, name, email, password, role, created_at, district)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (user_id, data['name'], data['email'], hashed_password, 'user', now, data.get('district', '')))

    conn.commit()
    conn.close()

    return jsonify({'message': 'Registration successful! Please login.'}), 201

@app.route('/api/auth/login', methods=['POST'])
def login():
    data = request.json
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute('SELECT * FROM users WHERE email = ?', (data['email'],))
    user = cursor.fetchone()
    conn.close()

    if not user or not check_password_hash(user['password'], data['password']):
        return jsonify({'error': 'Invalid email or password'}), 401

    session['user_id'] = user['id']
    session['name'] = user['name']
    session['role'] = user['role']
    session['email'] = user['email']

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE users SET last_login = ? WHERE id = ?', (datetime.now().isoformat(), user['id']))
    conn.commit()
    conn.close()

    return jsonify({
        'message': 'Login successful!',
        'user': {'id': user['id'], 'name': user['name'], 'email': user['email'], 'role': user['role']}
    })

@app.route('/api/auth/logout', methods=['POST'])
def logout():
    session.clear()
    return jsonify({'message': 'Logged out successfully'})

@app.route('/api/auth/me', methods=['GET'])
@login_required
def get_current_user():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT id, name, email, role, district, bio, phone, twitter, instagram, created_at FROM users WHERE id = ?', (session['user_id'],))
    user = cursor.fetchone()
    conn.close()
    return jsonify(dict(user))

@app.route('/api/auth/update', methods=['PUT'])
@login_required
def update_profile():
    data = request.json
    conn = get_db()
    cursor = conn.cursor()

    updates = []
    params = []

    if 'name' in data:
        updates.append('name = ?')
        params.append(data['name'])
    if 'bio' in data:
        updates.append('bio = ?')
        params.append(data['bio'])
    if 'district' in data:
        updates.append('district = ?')
        params.append(data['district'])
    if 'phone' in data:
        updates.append('phone = ?')
        params.append(data['phone'])
    if 'twitter' in data:
        updates.append('twitter = ?')
        params.append(data['twitter'])
    if 'instagram' in data:
        updates.append('instagram = ?')
        params.append(data['instagram'])
    if 'profile_pic' in data:
        updates.append('profile_pic = ?')
        params.append(data['profile_pic'])

    if not updates:
        conn.close()
        return jsonify({'error': 'No fields to update'}), 400

    params.append(session['user_id'])
    query = f'UPDATE users SET {", ".join(updates)} WHERE id = ?'
    cursor.execute(query, params)
    conn.commit()
    conn.close()

    # Update session name if changed
    if 'name' in data:
        session['name'] = data['name']

    return jsonify({'message': 'Profile updated successfully!'})

# ========== STORY API ==========
@app.route('/api/stories', methods=['GET'])
def get_stories():
    conn = get_db()
    cursor = conn.cursor()

    search = request.args.get('search', '')
    category = request.args.get('category', 'all')
    status = request.args.get('status', 'all')
    limit = request.args.get('limit', 50, type=int)
    offset = request.args.get('offset', 0, type=int)

    query = '''
        SELECT s.*, u.name as user_name, u.profile_pic as user_avatar,
               (SELECT COUNT(*) FROM comments WHERE story_id = s.id) as comment_count
        FROM stories s
        LEFT JOIN users u ON s.user_id = u.id
        WHERE 1=1
    '''
    params = []

    if search:
        query += ' AND (s.title LIKE ? OR s.content LIKE ? OR s.district LIKE ?)'
        search_param = f'%{search}%'
        params.extend([search_param, search_param, search_param])

    if category != 'all':
        query += ' AND s.category = ?'
        params.append(category)

    if status != 'all':
        query += ' AND s.status = ?'
        params.append(status)

    query += ' ORDER BY s.date DESC LIMIT ? OFFSET ?'
    params.extend([limit, offset])

    cursor.execute(query, params)
    stories = [dict(row) for row in cursor.fetchall()]
    conn.close()

    return jsonify({'stories': stories})

@app.route('/api/stories/<story_id>', methods=['GET'])
def get_story(story_id):
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute('''
        SELECT s.*, u.name as user_name, u.profile_pic as user_avatar
        FROM stories s
        LEFT JOIN users u ON s.user_id = u.id
        WHERE s.id = ?
    ''', (story_id,))

    story = cursor.fetchone()
    conn.close()

    if not story:
        return jsonify({'error': 'Story not found'}), 404

    # Increment views
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE stories SET views = views + 1 WHERE id = ?', (story_id,))
    conn.commit()
    conn.close()

    return jsonify(dict(story))

@app.route('/api/stories', methods=['POST'])
@login_required
def create_story():
    data = request.json
    story_id = str(uuid.uuid4())[:8]
    now = datetime.now().isoformat()

    conn = get_db()
    cursor = conn.cursor()

    cursor.execute('''
        INSERT INTO stories (
            id, title, content, district, category, language, author, user_id,
            date, likes, status, lat, lng
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', (
        story_id, data['title'], data['content'], data['district'],
        data.get('category', 'other'), data.get('language', 'English'),
        data.get('author', session.get('name', 'Anonymous')), session['user_id'],
        now, 0, 'pending', data.get('lat', None), data.get('lng', None)
    ))

    conn.commit()
    conn.close()

    return jsonify({'id': story_id, 'message': 'Story submitted!'}), 201

@app.route('/api/stories/<story_id>', methods=['PUT'])
@login_required
def update_story(story_id):
    data = request.json
    conn = get_db()
    cursor = conn.cursor()

    if 'likes' in data:
        cursor.execute('UPDATE stories SET likes = ? WHERE id = ?', (data['likes'], story_id))
    if 'status' in data and session.get('role') == 'admin':
        cursor.execute('UPDATE stories SET status = ? WHERE id = ?', (data['status'], story_id))

    conn.commit()
    conn.close()
    return jsonify({'message': 'Updated'})

@app.route('/api/stories/<story_id>', methods=['DELETE'])
@login_required
def delete_story(story_id):
    conn = get_db()
    cursor = conn.cursor()

    if session.get('role') != 'admin':
        cursor.execute('SELECT user_id FROM stories WHERE id = ?', (story_id,))
        story = cursor.fetchone()
        if not story or story['user_id'] != session['user_id']:
            conn.close()
            return jsonify({'error': 'Unauthorized'}), 403

    cursor.execute('DELETE FROM stories WHERE id = ?', (story_id,))
    cursor.execute('DELETE FROM comments WHERE story_id = ?', (story_id,))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Deleted'})

# ========== COMMENTS API ==========
@app.route('/api/stories/<story_id>/comments', methods=['GET'])
def get_comments(story_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT c.*, u.name as user_name, u.profile_pic as user_avatar
        FROM comments c
        LEFT JOIN users u ON c.user_id = u.id
        WHERE c.story_id = ?
        ORDER BY c.date DESC
    ''', (story_id,))
    comments = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify({'comments': comments})

@app.route('/api/stories/<story_id>/comments', methods=['POST'])
@login_required
def add_comment(story_id):
    data = request.json
    comment_id = str(uuid.uuid4())[:8]
    now = datetime.now().isoformat()

    conn = get_db()
    cursor = conn.cursor()

    cursor.execute('''
        INSERT INTO comments (id, story_id, user_id, user_name, content, date)
        VALUES (?, ?, ?, ?, ?, ?)
    ''', (comment_id, story_id, session['user_id'], session['name'], data['content'], now))

    conn.commit()
    conn.close()

    # Create notification for story owner
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT user_id FROM stories WHERE id = ?', (story_id,))
    story = cursor.fetchone()
    if story and story['user_id'] != session['user_id']:
        notification_id = str(uuid.uuid4())[:8]
        cursor.execute('''
            INSERT INTO notifications (id, user_id, message, type, created_at, link)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            notification_id,
            story['user_id'],
            f'{session["name"]} commented on your story',
            'comment',
            now,
            f'/story/{story_id}'
        ))
        conn.commit()
    conn.close()

    return jsonify({'id': comment_id, 'message': 'Comment added!'}), 201

# ========== STATS API ==========
@app.route('/api/stats', methods=['GET'])
def get_stats():
    conn = get_db()
    cursor = conn.cursor()

    cursor.execute('SELECT COUNT(*) FROM stories WHERE status = "published"')
    total_stories = cursor.fetchone()[0]

    cursor.execute('SELECT COUNT(DISTINCT district) FROM stories')
    total_districts = cursor.fetchone()[0]

    cursor.execute('SELECT COUNT(*) FROM users')
    total_users = cursor.fetchone()[0]

    cursor.execute('SELECT COUNT(*) FROM policy_briefs')
    total_briefs = cursor.fetchone()[0]

    conn.close()

    return jsonify({
        'stories': total_stories,
        'districts': total_districts,
        'users': total_users,
        'briefs': total_briefs or 5
    })

# ========== POLICY API ==========
@app.route('/api/policy', methods=['POST'])
@login_required
def generate_policy():
    data = request.json
    story_ids = data.get('story_ids', [])

    conn = get_db()
    cursor = conn.cursor()

    if story_ids:
        placeholders = ','.join('?' * len(story_ids))
        cursor.execute(f'SELECT * FROM stories WHERE id IN ({placeholders}) AND status = "published"', story_ids)
    else:
        cursor.execute('SELECT * FROM stories WHERE status = "published" LIMIT 5')

    stories = [dict(row) for row in cursor.fetchall()]
    conn.close()

    if not stories:
        return jsonify({'error': 'No published stories found'}), 400

    policy_id = str(uuid.uuid4())[:8]
    now = datetime.now().isoformat()

    categories = list(set([s['category'] for s in stories if s['category']]))
    districts = list(set([s['district'] for s in stories if s['district']]))
    theme = categories[0].title() if categories else 'Climate'

    recommendations = [
        "Invest in climate-resilient agriculture for women farmers",
        "Provide access to climate information in local languages",
        "Support women-led climate adaptation initiatives",
        "Integrate gender-responsive climate policies",
        "Increase funding for women's climate entrepreneurship",
        "Strengthen community-based early warning systems",
        "Promote sustainable land management practices",
        "Ensure women's participation in climate decision-making"
    ]

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        INSERT INTO policy_briefs (id, title, summary, recommendations, story_ids, generated_at, status)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ''', (
        policy_id,
        f'Policy Brief: {theme} Action in Uganda',
        f'This policy brief is based on {len(stories)} stories from women across {len(districts)} districts in Uganda, highlighting the urgent need for gender-responsive climate policies.',
        json.dumps(recommendations[:5]),
        json.dumps([s['id'] for s in stories]),
        now,
        'published'
    ))
    conn.commit()
    conn.close()

    return jsonify({
        'id': policy_id,
        'title': f'Policy Brief: {theme} Action in Uganda',
        'summary': f'This policy brief is based on {len(stories)} stories from women across {len(districts)} districts.',
        'recommendations': recommendations[:5],
        'generated_at': now,
        'status': 'published'
    }), 201

@app.route('/api/policy/briefs', methods=['GET'])
def get_policy_briefs():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM policy_briefs ORDER BY generated_at DESC')
    briefs = [dict(row) for row in cursor.fetchall()]
    for b in briefs:
        if b['recommendations']:
            b['recommendations'] = json.loads(b['recommendations'])
        if b['story_ids']:
            b['story_ids'] = json.loads(b['story_ids'])
    conn.close()
    return jsonify({'briefs': briefs})

# ========== NOTIFICATIONS API ==========
@app.route('/api/notifications', methods=['GET'])
@login_required
def get_notifications():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('''
        SELECT * FROM notifications
        WHERE user_id = ?
        ORDER BY created_at DESC
        LIMIT 20
    ''', (session['user_id'],))
    notifications = [dict(row) for row in cursor.fetchall()]
    conn.close()
    return jsonify({'notifications': notifications})

@app.route('/api/notifications/<notification_id>/read', methods=['PUT'])
@login_required
def mark_notification_read(notification_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE notifications SET read = 1 WHERE id = ? AND user_id = ?', (notification_id, session['user_id']))
    conn.commit()
    conn.close()
    return jsonify({'message': 'Marked as read'})

@app.route('/api/notifications/read-all', methods=['PUT'])
@login_required
def mark_all_read():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('UPDATE notifications SET read = 1 WHERE user_id = ?', (session['user_id'],))
    conn.commit()
    conn.close()
    return jsonify({'message': 'All notifications marked as read'})

# ========== RUN ==========
if __name__ == '__main__':
    init_db()
    app.run(debug=True, host='0.0.0.0', port=5000)
